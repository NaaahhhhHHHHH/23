export const sygnet = [
  '95 98',
  `<svg fill="#000156" width="90px" height="90px" viewBox="1 -3 32.00 32.00" id="icon" xmlns="http://www.w3.org/2000/svg" >

<g id="SVGRepo_bgCarrier" stroke-width="0"/>

<g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"/>

<g id="SVGRepo_iconCarrier">

<defs>

<style>.cls-1{fill:none;}</style>

</defs>

<title>app</title>

<path d="M28,10H22V24h2V20h4a2.0027,2.0027,0,0,0,2-2V12A2.0023,2.0023,0,0,0,28,10Zm-4,8V12h4v6Z"/>

<path d="M18,10H12V24h2V20h4a2.0027,2.0027,0,0,0,2-2V12A2.0023,2.0023,0,0,0,18,10Zm-4,8V12h4v6Z"/>

<path d="M8,10H3v2H8v2H4a2,2,0,0,0-2,2v2a2,2,0,0,0,2,2h6V12A2.0023,2.0023,0,0,0,8,10Zm0,8H4V16H8Z"/>

<rect id="_Transparent_Rectangle_" data-name="&lt;Transparent Rectangle&gt;" class="cls-1" width="32" height="32"/>

</g>

</svg>`,
]
